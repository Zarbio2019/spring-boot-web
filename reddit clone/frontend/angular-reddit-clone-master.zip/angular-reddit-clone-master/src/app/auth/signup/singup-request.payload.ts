export interface SignupRequestPayload {
    username: string;
    password: string;
    email: string;
}
